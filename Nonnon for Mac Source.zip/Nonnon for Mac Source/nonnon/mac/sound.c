// Project Nonnon
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_MAC_SOUND
#define _H_NONNON_MAC_SOUND




#import <AVFoundation/AVFoundation.h>




#define n_mac_sound_wav_init( wav_name ) n_mac_sound_init( wav_name, @"wav" )

AVAudioPlayer*
n_mac_sound_init( NSString *resource_name, NSString *ext )
{

	// [!] : resource_name
	//
	//	[ how to register ]
	//
	//		DnD to left side of Xcode
	//
	//	[ pitfalls ]
	//
	//		resource_name needs no extension
	//		for example : "mew.wav" => "mew" and "wav"


	NSBundle *main = [NSBundle mainBundle];
	NSString *path = [main pathForResource:resource_name ofType:ext];
//NSLog( @"%@", path );

	NSURL    *url  = [NSURL fileURLWithPath:path];
//NSLog( @"%@", url );

	return [[AVAudioPlayer alloc] initWithContentsOfURL:url error:nil];
}

void
n_mac_sound_loop_count( AVAudioPlayer *player, int value )
{

	// [!] : -1 for value : infinite loop playback

	player.numberOfLoops = value;


	return;
}

#define n_mac_sound_play(  player ) [player  play]
#define n_mac_sound_stop(  player ) [player  stop]
#define n_mac_sound_pause( player ) [player pause]




#endif // _H_NONNON_MAC_SOUND


