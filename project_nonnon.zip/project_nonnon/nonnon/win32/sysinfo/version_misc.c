// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_SYSINFO_VERSION_MISC
#define _H_NONNON_WIN32_SYSINFO_VERSION_MISC




#include "../registry.c"




int
n_sysinfo_version_ie( n_posix_char *ret )
{

	DWORD cch = 100;
	DWORD cb  = cch * sizeof( n_posix_char );

	n_posix_char str[ 100 ]; n_string_zero( str, cch );

	DWORD dw = n_registry_read
	(
		HKEY_LOCAL_MACHINE,
		n_posix_literal( "Software\\Microsoft\\Internet Explorer" ),
		n_posix_literal( "svcVersion" ),
		str,
		cb
	);

	if ( dw != ERROR_SUCCESS )
	{

		n_registry_read
		(
			HKEY_LOCAL_MACHINE,
			n_posix_literal( "Software\\Microsoft\\Internet Explorer" ),
			n_posix_literal( "Version" ),
			str,
			cb
		);

	}

	if ( ret != NULL ) { n_string_copy( str, ret );  }

//n_posix_debug_literal( "%s : %d", str, n_posix_atoi( str ) );


	return n_posix_atoi( str );
}

int
n_sysinfo_version_wmp( n_posix_char *ret )
{

	// [!] : Default
	//
	//	[ Default ]
	//	Win95   : x : ""
	//	Win98SE : x : "6,1,5,130"
	//	Win2000 : o : "6,4,9,1125"
	//	WinXP   : o : "10,0,0,3650"
	//	Win7    : o : "12,0,7601,3650"
	//
	//	[ WMP6.4 ]
	//	Win98SE : o : "6,4,07,1112"


	DWORD cch = 100;
	DWORD cb  = cch * sizeof( n_posix_char );

	n_posix_char str[ 100 ]; n_string_zero( str, cch );

	n_registry_read
	(
		HKEY_LOCAL_MACHINE,
		n_posix_literal( "Software\\Microsoft\\MediaPlayer\\PlayerUpgrade" ),
		n_posix_literal( "PlayerVersion" ),
		str,
		cb
	);

	if ( ret != NULL ) { n_string_copy( str, ret );  }

//n_posix_debug_literal( "%s : %d", str, atoi( str ) );


	return n_posix_atoi( str );
}


#endif // _H_NONNON_WIN32_SYSINFO_VERSION_MISC


