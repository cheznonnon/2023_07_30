// Watchcat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_COM_ISHELLLINK
#define _H_NONNON_WIN32_COM_ISHELLLINK




#include "./com.c"

#include "../neutral/string_path.c"




#ifdef UNICODE


#define n_guid_IID_IShellLink n_guid_IID_IShellLinkW


#define IShellLink_GetPath         IShellLinkW_GetPath
#define IShellLink_SetPath         IShellLinkW_SetPath
#define IShellLink_GetIconLocation IShellLinkW_GetIconLocation
#define IShellLink_SetIconLocation IShellLinkW_SetIconLocation
#define IShellLink_GetArguments    IShellLinkW_GetArguments
#define IShellLink_SetArguments    IShellLinkW_SetArguments


#else  // #ifdef UNICODE


#define n_guid_IID_IShellLink n_guid_IID_IShellLinkA


#define IShellLink_GetPath         IShellLinkA_GetPath
#define IShellLink_SetPath         IShellLinkA_SetPath
#define IShellLink_GetIconLocation IShellLinkA_GetIconLocation
#define IShellLink_SetIconLocation IShellLinkA_SetIconLocation
#define IShellLink_GetArguments    IShellLinkA_GetArguments
#define IShellLink_SetArguments    IShellLinkA_SetArguments


#endif // #ifdef UNICODE




#define N_ISHELLLINK_EXT n_posix_literal( ".lnk\0\0" )




n_posix_bool
n_IShellLink_is_shortcut( const n_posix_char *name )
{

	n_posix_bool ret = n_posix_false;


	if (
		( n_posix_stat_is_file( name ) )
		&&
		( n_string_path_ext_is_same( N_ISHELLLINK_EXT, name ) )
	)
	{
		ret = n_posix_true;
	}


	return ret;
}

void
n_IShellLink_path2lnk
(
	n_posix_char *name,
	n_posix_char *path,
	n_posix_char *args,
	n_posix_char *icon,
	n_type_gfx    icon_number
)
{
//n_posix_debug_literal( "%s\n%s\n%s", name, path, args ); return;

	// [Mechanism]
	//
	//	each parameters are semi-const
	//	real data are read-only, but pointer variables are overwritten
	//
	//	name        : [ Needed ] : .LNK name : absolute path
	//	path        : [ Needed ] : a target path
	//	args        : [Optional] : commandline option
	//	icon        : [Optional] : icon name
	//	icon_number : [Optional] : icon number


	if ( n_string_is_empty( path ) ) { return; }
	if ( n_string_is_empty( name ) ) { return; }


	if ( icon_number > INT_MAX ) { return; }


	if ( n_string_is_empty( args ) ) { args = N_STRING_EMPTY; }
	if ( n_string_is_empty( icon ) ) { icon = path; }


	n_com_init();


	IShellLink   *sl;
	IPersistFile *pf;


	n_com_class    ( n_guid_CLSID_ShellLink, n_guid_IID_IShellLink,   (void*) &sl );
	n_com_interface(                     sl, n_guid_IID_IPersistFile, (void*) &pf );

	if ( ( sl == NULL )||( pf == NULL ) )
	{

		n_com_release( sl );
		n_com_release( pf );

		n_com_exit();


		return;
	}


	// [!] : Win95 : backslash only
	//
	//	before : "C:/nonnon_win/catpad.exe"
	//	after  : "C:\\nonnon_win/catpad.exe" => handled as not exist

	// [!] : Not Needed : SetArguments( sl, "%1" );

	IShellLink_SetPath        ( sl, path );
	IShellLink_SetArguments   ( sl, args );
	IShellLink_SetIconLocation( sl, icon, (int) icon_number );


	{

		n_posix_char *lnk = n_string_path_cat( name, N_ISHELLLINK_EXT, NULL );
//n_posix_debug_literal( "%s", lnk );

		{
			BSTR bstr = n_com_bstr_init( lnk );
//n_com_debug_w( bstr );
			IPersistFile_Save( pf, bstr, n_posix_true );

			n_com_bstr_exit( bstr );
		}

		n_string_free( lnk );

	}


	n_com_release( sl );
	n_com_release( pf );


	n_com_exit();


	return;
}

#define N_ISHELLLINK_LNK2PATH_CCH_PATH ( MAX_PATH )
#define N_ISHELLLINK_LNK2PATH_CCH_ARGS (   1024   )

void
n_IShellLink_lnk2path
(
	const n_posix_char *lnk,
	      n_posix_char *path,
	      n_posix_char *args,
	      n_posix_char *icon,
	      n_type_gfx   *icon_number
)
{

	if ( n_posix_false == n_IShellLink_is_shortcut( lnk ) )
	{

		if ( path != NULL ) { n_string_copy( lnk, path ); }

		return;
	}


	n_com_init();


	IShellLink   *sl = NULL;
	IPersistFile *pf = NULL;


	n_com_class    ( n_guid_CLSID_ShellLink, n_guid_IID_IShellLink,   (void*) &sl );
	n_com_interface(                     sl, n_guid_IID_IPersistFile, (void*) &pf );

	if ( ( sl == NULL )||( pf == NULL ) )
	{
//n_posix_debug_literal( "%s", lnk );

		n_com_release( sl );
		n_com_release( pf );

		n_com_exit();


		return;
	}


	{

		BSTR bstr = n_com_bstr_init( lnk );


		IPersistFile_Load( pf, bstr, STGM_READ );


		n_com_bstr_exit( bstr );

	}


	// [!] : GetArguments() : maximum length
	//
	//	MAX_PATH : 260

	if ( path != NULL ) { IShellLink_GetPath( sl, path, N_ISHELLLINK_LNK2PATH_CCH_PATH, NULL, 0 ); }


	// [!] : GetArguments() : maximum length
	//
	//	before Win2000    : MAX_PATH    :  260
	//	Win2000 and later : INFOTIPSIZE : 1024

	if ( args != NULL ) { IShellLink_GetArguments( sl, args, N_ISHELLLINK_LNK2PATH_CCH_ARGS ); }


	if ( ( icon != NULL )&&( icon_number != NULL ) )
	{
		int number = 0;
		IShellLink_GetIconLocation( sl, icon, N_ISHELLLINK_LNK2PATH_CCH_PATH, &number );
		(*icon_number) = (n_type_gfx) number;
	}


	n_com_release( sl );
	n_com_release( pf );


	n_com_exit();


	return;
}

void
n_IShellLink_iotest( n_posix_char *cmdline )
{

	if ( n_string_path_ext_is_same( N_ISHELLLINK_EXT, cmdline ) )
	{

		n_posix_char path[ N_ISHELLLINK_LNK2PATH_CCH_PATH ];
		n_posix_char args[ N_ISHELLLINK_LNK2PATH_CCH_ARGS ];


		n_IShellLink_lnk2path( cmdline, path, args, NULL, NULL );

		n_posix_debug_literal( "%s : %s", path, args );

	} else {

		n_IShellLink_path2lnk( NULL, cmdline, NULL, NULL, 0 );

	}


	return;
}


#endif // _H_NONNON_WIN32_COM_ISHELLLINK

