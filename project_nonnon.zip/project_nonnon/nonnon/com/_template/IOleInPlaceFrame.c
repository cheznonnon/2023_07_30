// Nonnon COM : IOleInPlaceFrame
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File : copy and modify if needed


// [!] : this interface has IOleWindow and IOleInPlaceUIWindow




#ifndef _H_NONNON_WIN32_COM_IOLEINPLACEFRAME
#define _H_NONNON_WIN32_COM_IOLEINPLACEFRAME




HRESULT __stdcall
n_IOleInPlaceFrame_IUnknown_QueryInterface( void *_this, REFIID iid, void **ppvObject )
{

	if ( ppvObject == NULL ) { return E_POINTER; } else { (*ppvObject) = NULL; }


	GUID u = n_com_guid( n_guid_IID_IUnknown );
	GUID w = n_com_guid( n_guid_IID_IOleWindow );
	GUID i = n_com_guid( n_guid_IID_IOleInPlaceUIWindow );
	GUID f = n_com_guid( n_guid_IID_IOleInPlaceFrame );


	if (
		( IsEqualGUID( iid, &u ) )
		||
		( IsEqualGUID( iid, &w ) )
		||
		( IsEqualGUID( iid, &i ) )
		||
		( IsEqualGUID( iid, &f ) )
	)
	{

		(*ppvObject) = _this;

		return S_OK;
	}


	return E_NOINTERFACE;
}




HRESULT __stdcall
n_IOleInPlaceFrame_IOleWindow_GetWindow( void *_this, HWND *phwnd )
{

	if ( phwnd == NULL ) { return E_INVALIDARG; }


	*phwnd = n_IOleInPlaceSite_hwnd;


	return S_OK;
}

HRESULT __stdcall
n_IOleInPlaceFrame_IOleWindow_ContextSensitiveHelp( void *_this, BOOL fEnterMode )
{
	return E_NOTIMPL;
}




HRESULT __stdcall
n_IOleInPlaceFrame_IOleInPlaceUIWindow_GetBorder( void *_this, LPRECT lprectBorder )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IOleInPlaceFrame_IOleInPlaceUIWindow_RequestBorderSpace( void *_this, LPCBORDERWIDTHS pborderwidths )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IOleInPlaceFrame_IOleInPlaceUIWindow_SetBorderSpace( void *_this, LPCBORDERWIDTHS pborderwidths )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IOleInPlaceFrame_IOleInPlaceUIWindow_SetActiveObject( void *_this, IOleInPlaceActiveObject *pActiveObject, LPCOLESTR pszObjName )
{
	return S_OK;
}




HRESULT __stdcall
n_IOleInPlaceFrame_InsertMenus( void *_this, HMENU hmenuShared,LPOLEMENUGROUPWIDTHS lpMenuWidths )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IOleInPlaceFrame_SetMenu( void *_this, HMENU hmenuShared, HOLEMENU holemenu, HWND hwndActiveObject )
{
	return S_OK;
}

HRESULT __stdcall
n_IOleInPlaceFrame_RemoveMenus( void *_this, HMENU hmenuShared )
{
	return E_NOTIMPL;
}

HRESULT __stdcall
n_IOleInPlaceFrame_SetStatusText( void *_this, LPCOLESTR pszStatusText )
{
	return S_OK;
}

HRESULT __stdcall
n_IOleInPlaceFrame_EnableModeless( void *_this, BOOL fEnable )
{
	return S_OK;
}

HRESULT __stdcall
n_IOleInPlaceFrame_TranslateAccelerator( void *_this, LPMSG lpmsg, WORD wID )
{
	return E_NOTIMPL;
}




const void *n_IOleInPlaceFrame_Vtbl[] = {

	n_IOleInPlaceFrame_IUnknown_QueryInterface,
	n_com_IUnknown_AddRef,
	n_com_IUnknown_Release,

	n_IOleInPlaceFrame_IOleWindow_GetWindow,
	n_IOleInPlaceFrame_IOleWindow_ContextSensitiveHelp,

	n_IOleInPlaceFrame_IOleInPlaceUIWindow_GetBorder,
	n_IOleInPlaceFrame_IOleInPlaceUIWindow_RequestBorderSpace,
	n_IOleInPlaceFrame_IOleInPlaceUIWindow_SetBorderSpace,
	n_IOleInPlaceFrame_IOleInPlaceUIWindow_SetActiveObject,

	n_IOleInPlaceFrame_InsertMenus,
	n_IOleInPlaceFrame_SetMenu,
	n_IOleInPlaceFrame_RemoveMenus,
	n_IOleInPlaceFrame_SetStatusText,
	n_IOleInPlaceFrame_EnableModeless,
	n_IOleInPlaceFrame_TranslateAccelerator,

};


IOleInPlaceFrame n_IOleInPlaceFrame_instance = { (void*) n_IOleInPlaceFrame_Vtbl };




#endif // _H_NONNON_WIN32_COM_IOLEINPLACEFRAME

