// Nonnon COM : IServiceProvider
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File : copy and modify if needed




#ifndef _H_NONNON_WIN32_COM_ISERVICEPROVIDER
#define _H_NONNON_WIN32_COM_ISERVICEPROVIDER




//#include "com.c"




HRESULT __stdcall
n_IServiceProvider_IUnknown_QueryInterface( void *_this, REFIID iid, void **ppvObject )
{
//N_COM_DEBUG_LISTBOX_SET_A( "IServiceProvider_IUnknown_QueryInterface" );
n_posix_debug_literal( "IServiceProvider_IUnknown_QueryInterface" );


	n_com_debug_IUnknown_QueryInterface( _this, iid, ppvObject );


	if ( ppvObject == NULL ) { return E_POINTER; } else { (*ppvObject) = NULL; }


	GUID u = n_com_guid( n_guid_IID_IUnknown );
	GUID s = n_com_guid( n_guid_IID_IServiceProvider );


	if (
		( IsEqualGUID( iid, &u ) )
		||
		( IsEqualGUID( iid, &s ) )
	)
	{

		(*ppvObject) = _this;

		return S_OK;
	}


	return E_NOINTERFACE;
}




HRESULT __stdcall
n_IServiceProvider_QueryService( void *_this, REFGUID guidService, REFIID riid, void **ppv )
{
n_posix_debug_literal( "IServiceProvider_QueryService" );


	// [Mechanism]
	//
	//	{4C96BE40-915C-11CF-99D3-00AA004AE837} : SID_STopLevelBrowser
	//	{02BA3B52-0547-11D1-B833-00C04FC9B31F} : IID_IBrowserService


	if ( ppv == NULL ) { return E_POINTER; } else { (*ppv) = NULL; }


/*
	n_posix_char sid[ 100 ];
	n_posix_char iid[ 100 ];

	n_com_debug_guid2str( *guidService, sid );
	n_com_debug_guid2str( *riid,        iid );

	n_posix_debug_literal( "SID : %s\nIID : %s", sid, iid );
*/


	// [!] : Shdeprecated.h

	GUID s = n_com_guid( n_guid_SID_STopLevelBrowser );
	GUID i = n_com_guid( n_guid_IID_IBrowserService  );


	if ( ( IsEqualGUID( guidService, &s ) )&&( IsEqualGUID( riid, &i ) ) )
	{

		//extern IServiceProvider n_IServiceProvider_instance;

		//(*ppv) = (void*) &n_IServiceProvider_instance;

		//return S_OK;

	}


	return E_NOINTERFACE;
}




const void *n_IServiceProvider_Vtbl[] = {

	n_IServiceProvider_IUnknown_QueryInterface,
	n_com_IUnknown_AddRef,
	n_com_IUnknown_Release,

	n_IServiceProvider_QueryService,

};


IServiceProvider n_IServiceProvider_instance = { (void*) n_IServiceProvider_Vtbl };




#endif // _H_NONNON_WIN32_COM_ISERVICEPROVIDER

